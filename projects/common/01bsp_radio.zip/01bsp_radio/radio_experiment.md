# Radio packet logging experiment

This guide describes how to run the sequence-number packet experiment, collect
logs at multiple distances, and analyse the results.

## Firmware preparation

1. Build and flash the updated `projects/common/01bsp_radio/01bsp_radio.c`
   firmware on both DK boards.
2. **Transmitter**: leave the default `CHANNEL` value (or configure the channel
   you want to test). The firmware now constructs each outgoing packet as:
   - Byte 0: 8-bit sequence counter (wraps 0→255→0 automatically).
   - Bytes 1..N: filled with `0xAA` to provide a recognisable pattern.
3. **Receiver**: flashes the same firmware. In RX mode it validates the fill
   pattern and prints one UART line per accepted packet in the format:
   ```
   <length> <sequence> <crc_ok> <rssi>
   ```
   where `length` is the MAC payload length (including CRC bytes), `sequence`
   is the TX counter, `crc_ok` is 1 when the radio reported a valid CRC, and
   `rssi` is the signed RSSI value reported by the radio driver.

## Host tools

Install the Python dependencies once (recommend using a virtual environment):

```bash
python3 -m pip install --user pyserial matplotlib
```

### Real-time logging per distance

Use `scripts/log_serial_packets.py` to capture UART output to a log file. Run
one command per distance measurement:

```bash
python3 scripts/log_serial_packets.py /dev/ttyUSB0 20
python3 scripts/log_serial_packets.py /dev/ttyUSB0 50 --append
...
```

Each run creates (or appends to) `log_<distance>cm_pkt.log`. The script keeps
only lines matching the expected ``len seq crc rssi`` format, so the log files
are ready for post-processing.

Recommended distances for the assignment:

- `log_20cm_pkt.log`
- `log_50cm_pkt.log`
- `log_100cm_pkt.log`
- `log_200cm_pkt.log`
- `log_300cm_pkt.log`
- `log_400cm_pkt.log`

### Plotting PDR and RSSI trends

After collecting all logs, generate the summary plot:

```bash
python3 scripts/plot_pdr_rssi.py --log-dir . --save radio_results.png --verbose
```

The script computes:

- **PDR** (Packet Delivery Ratio) using the sequence numbers, counting any
  skipped values as packet losses.
- **Average RSSI** with standard-deviation error bars per distance.

Pass `--show` to open the matplotlib window, or omit `--save` to display the
plots interactively.
